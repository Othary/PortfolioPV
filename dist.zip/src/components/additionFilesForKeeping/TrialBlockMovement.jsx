import React from 'react'



const TrialBlockMovement = () => {
  return (
    <>
        <div className='flex items-center justify-center w-full min-h-screen bg-[#0a192f] text-gray-300'>
            <div className='w-[$wid] h-64 border-white border-4'>
                <div className="">TrialBlockMovement</div>            
            </div>
            <button >Click me</button>
        </div>
        
    </>
  )
}

export default TrialBlockMovement